// PlaceholderImg.jsx
export function PlaceholderImg(size = 300) {
  return `https://via.placeholder.com/${size}`;
}
