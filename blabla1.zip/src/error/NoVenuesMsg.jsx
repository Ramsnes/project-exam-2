export function NoVenuesMsg() {
  <div className="noVenues">No venues available</div>;
}
