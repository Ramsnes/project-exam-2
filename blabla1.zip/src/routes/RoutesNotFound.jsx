// import React from "react";

// function RouteNotFound() {
//   return <div>Page not found</div>;
// }

// export default RouteNotFound;
