// Loader.jsx
export function Loader() {
  return <div className="loader"></div>;
}
